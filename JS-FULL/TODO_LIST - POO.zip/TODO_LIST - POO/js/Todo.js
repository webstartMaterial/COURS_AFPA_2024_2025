class Todo {

    static idCount = 0; // variable/attribut de classe (elle n'appartient aux objets créés mais à la classe)

    constructor(text, date, reminder) {

        this.id = Todo.idCount++; // membre d'instance
        this.text = text;
        this.date = date;
        this.reminder = reminder;

        // capter les événement autour du todo

    }

}

export default Todo;