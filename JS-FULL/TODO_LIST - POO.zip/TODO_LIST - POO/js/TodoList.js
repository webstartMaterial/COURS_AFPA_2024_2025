import LocalStorage from "./LocalStorage.js";
import Dom from "./Dom.js";
import EventHandler from "./EventHandler.js";
import Todo from "./Todo.js";

class TodoList {

    // CRUD (CREATE READ UPDATE DELETE)

    constructor(btn_form, form, btn_clear_all, todo_list, btn_remind, count) {
        this.btn_form = btn_form; 
        this.form = form; 
        this.btn_clear_all = btn_clear_all; 
        this.todo_list = todo_list; 
        this.btn_remind = btn_remind;
        this.count = count;

        // capter les événement autour de la todo list
        EventHandler.triggerEvent(this.form, 'submit', () => this.create());
        EventHandler.triggerEvent(this.btn_clear_all, 'click', () =>  this.deleteAll());
        EventHandler.triggerEvent(this.btn_remind, 'click', () =>  this.toggleReminder());
        EventHandler.triggerEvent(this.btn_form, 'click', () => this.toggleShowForm());

        console.log("Création de ma todoList et lacement des capteurs d'événements");

    }

    /**
     * Retourne les todos qui sont dans le localStorage
     * @returns 
     */
    getAll() {
        console.log("Récupération de tous les todos en BDD...");
        return LocalStorage.findAll('todos');
    }

    /**
     * Met à jour la liste HTML
     * @param {*} todos 
     */
    updateTodoList(todos) {

        console.log("Mise à jour de la liste HTML contenant les todos...");
        Dom.modifyHtml(this.todo_list, '');

        todos.forEach((todo) => {
    
            let todoHTML = Dom.createElementsWithInnerElem(
                [ 'li', `todo-item ${ todo.reminder ? 'reminder' : '' }`, todo.id], 
                [ 
                    ['span', '', `${todo.text} - ${todo.date}`],
                    ['span', 'delete-btn', '✖']
                ]
            );

            Dom.appendChild(this.todo_list, todoHTML);
            EventHandler.triggerEvent(todoHTML, 'dblclick', () => this.update(todoHTML));
            EventHandler.triggerEvent(todoHTML.querySelector('.delete-btn'), 'click', () => this.delete(todoHTML));
        
        });

        this.updateCounter();

    }

    /**
     * je charge mes todos et les affiche à l'écran
     */
    loadTodos() {

        console.log("Chargement des todos...");
        let todos = this.getAll();
        this.updateTodoList(todos);

    }

    /**
     * Je créer un todo pour l'ajouter à ma liste
     */
    create () {

        console.log("Création d'un todo");
        // je récupère les valeurs soumises de mon formulaire
        let text = Dom.getValueElement('#task');
        let date = Dom.getValueElement('#due-date');
        let reminder = Dom.getValueCheckElement('#reminder');

        let newTodo = new Todo(text, date, reminder);

        this.addTodoToList(newTodo);

    }

    /**
     * J'ajoute mon todo à mon localStorage pour l'ajouter à ma liste HTML
     * 
     */
    addTodoToList(newTodo) {

        console.log("Ajout d'un todo dans ma liste HTML...");
        // je récupère les données actuellement dans mon localstorage
        let listTodos = this.getAll();
        listTodos.push(newTodo);
        LocalStorage.update('todos', listTodos);
        this.form.reset();

        this.updateTodoList(listTodos);

    }

    /**
     * Je supprime mon Todo pour mettre à jour ma liste
     */
    delete(elemHtml) {

        console.log("Suppression d'un todo...")
        let listTodos = this.getAll();
        let listTodosUpdated = listTodos.filter((todo) => {
            return todo.id != elemHtml.id;
        });

        localStorage.setItem("todos", JSON.stringify(listTodosUpdated));
        this.updateTodoList(listTodosUpdated);
        this.updateCounter(); // remet à jour le compteur

    }

    /**
     * Je supprime tous mes todos
     */
    deleteAll() {
        
        console.log("Suppression de tous les todos...");
        LocalStorage.deleteAll("todos");
        this.updateTodoList([]); // recharge la liste
        this.updateCounter(); // remet à jour le compteur
    
    }

    /**
     * Je mets à jour le compteur
     */
    updateCounter() {

        console.log("Mise à jour du compteur...");
        let listTodos = this.getAll();
        Dom.modifyHtml(this.count, listTodos.length);
    
        if(listTodos.length > 0) {
            Dom.toggleClass(this.btn_clear_all, 'hide', 'remove');
        } else {
            Dom.toggleClass(this.btn_clear_all, 'hide', 'add');
        }

    }

    /**
     * J'affiche tous les todos /ou les todos filtrés
     */
    toggleReminder() {

        console.log("Filtrage des todos par rappel");
        Dom.toggleClass(this.todo_list, 'filtered', 'toggle');

        let filtered = Dom.containsClass(this.todo_list, 'filtered');
        let listTodos = this.getAll();
        let listFiltered;

        if(filtered) {
            listFiltered = listTodos.filter((todo) => {
                return todo.reminder;
            });
        } else {
            listFiltered = this.getAll();
        }

        this.updateTodoList(listFiltered);
        Dom.toggleElement(this.btn_remind, 'bg-green', 'bg-blue', filtered ? 'Tous' : 'Par rappel');
    
    }


    /**
     * Permet de mettre à jour un todo
     */
    update(todo) {

        console.log("Mise à jour d'un todo...");
        let id = todo.id;
        let listTodos = this.getAll();

        let listTodosUpdated = listTodos.map((todo) => {
            return todo.id == id ? {...todo, reminder : !todo.reminder} : todo
        });

        LocalStorage.update('todos', listTodosUpdated);
        this.updateTodoList(listTodosUpdated);

    }

    toggleShowForm() {
        console.log("toto");
        console.log(this.btn_form);
        Dom.toggleClass(this.form, 'hide', 'toggle');
        Dom.toggleElement(this.btn_form, 
            'bg-green', 'bg-red', 
            Dom.containsClass(this.form, 'hide') ? 'Montrer' : 'Cacher');
    }

}

export default TodoList;