class EventHandler {


    static triggerEvent(elemHTML, triggeredEvent, callBack) {

        elemHTML.addEventListener(triggeredEvent, (e) => {
            e.preventDefault();
            callBack();
        });

    }

}

export default EventHandler;