import TodoList from "./TodoList.js";

const BTN_TOGGLE_FORM = document.querySelector(".toggleForm");
const TODO_FORM = document.querySelector(".todo-form");
const COUNT = document.querySelector("#count");
const CLEAR_ALL = document.querySelector(".clear-all");
const TODO_LIST = document.querySelector(".todo-list");
const REMIND_ALL = document.querySelector(".reminder-all");

// objectif c'est de n'afficher que les todos qui ont un rappel

let todoList = new TodoList(BTN_TOGGLE_FORM,TODO_FORM, CLEAR_ALL,TODO_LIST,REMIND_ALL,COUNT);
todoList.loadTodos();