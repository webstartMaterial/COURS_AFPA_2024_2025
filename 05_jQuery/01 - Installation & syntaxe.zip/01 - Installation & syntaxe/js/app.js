$(document).ready(function () {
    console.log("Hello world !");
});