$("document").ready(function () {

    // ANIMATION 1
    function animation1() {
        $(".animation1").css("width", "50px");
        $(".animation1").animate({
            width: "200px"
        }, 2000, function () {
            $(".animation1").animate({
                width: "50px"
            }, 2000, function () {
                animation1();
            });
        });
    }
    animation1();

    // ANIMATION 2
    function animation2() {
        $(".animation2").css("right", "-200px");
        $(".animation2").animate({
            right: "+=500"
        }, 2000, 'linear', function () {
            animation2();
        });
    }
    animation2();

    // ANIMATION 3

    function animation3() {
        $(".animation3").animate({
            opacity: '0'
        }, 2000, 'linear', function () {
            $(".animation3").animate({
                opacity: "1"
            }, 2000, function () {
                animation3();
            })
        });
    }
    animation3();

    // ANIMATION 4

    function animation4() {
        $(".animation4").css("width", "50px");
        $(".animation4").animate({
            width: "150px"
        }, 200, 'linear', function () {
            $(".animation4").animate({
                width: "100px"
            }, 200, function () {
                $(".animation4").animate({
                    width: "150px"
                }, 200, 'linear', function () {
                    setTimeout(function () {
                        animation4();a
                    }, 1000);
                });
            });
        });

    }

    animation4();

    // ANIMATION 5
    $(".animation5").click(function () {
        $(this).animate({
            top: "-150px",
            right: "-150px"
        }, 2000, function () {
            alert("Animation done !");
        });
    });


});