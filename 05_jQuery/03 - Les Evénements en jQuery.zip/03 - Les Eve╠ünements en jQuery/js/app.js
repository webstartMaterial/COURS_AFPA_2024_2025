$(document).ready(function () {

    // CLICK
    $("img").eq(0).click(function () {
        alert("Hello World!");
    });

    // HOVER
    // $("img").eq(1).hover(function () {
    //     $(this).css("width", "150px");
    // });

    // CALL BACK FUNCTION
    $("img").eq(1).hover(function () {
        $(this).css("width", "150px");
    }, function () {
        $(this).css("width", "200px");
    });

    // DBL CLICK
    $("img").eq(2).dblclick(function () {
        $(this).css("border", "2px solid red");
    });

    // KEYPRESS
    $(document).keypress(function (event) {
        // console.log("keyboard pressed !");
        console.log(event.key);
    });

    // EVENT OBJECT
    $("#myForm").submit(function (event) {
        event.preventDefault();
        console.log("Submit not triggered!");
    });

    // CALL BACK FUNCTION
    $("img").hover(function () {
        $(this).css("box-shadow", "10px 10px 5px 0px rgba(0,0,0,0.75)");
    }, function () {
        $(this).css("box-shadow", "10px 10px 5px 0px rgba(0,0,0,0)");
    });

});